#include "stdafx.h"
#include "NAWLink.h"


NAWLink::NAWLink()
{
}

NAWLink::NAWLink( const NAW&, NAWLink* )
{
}

NAWLink::~NAWLink()
{
}
