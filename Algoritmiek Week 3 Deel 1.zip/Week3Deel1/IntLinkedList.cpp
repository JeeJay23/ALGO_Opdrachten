#include "stdafx.h"

#include "IntLinkedList.h"

#include "IntLink.h"

#include <iostream>

IntLinkedList::IntLinkedList()
{
}


IntLinkedList::~IntLinkedList()
{
}

IntLink* IntLinkedList::getAt( int ) const
{
    return nullptr;
}

bool IntLinkedList::setAt( int, int )
{
    bool succeeded = false;

    return succeeded;
}

int IntLinkedList::length1() const
{
    return -1;
}

int IntLinkedList::length2() const
{
    return -1;
}

void IntLinkedList::bubbleSort()
{
}

/*
 *  geschatte snelheid van dit algoritme: O(...)
 *  onderbouwing:
 *
 *
 */

 /*
 * metingen van de duur van het sorteren...
 *
 *    aantal waarden:       duur in us:
 *        1000
 *        2000
 *        5000
 *       10000
 *         ...
 */  

/*
 *  gemeten snelheid van dit algoritme: O(...)
 *  onderbouwing:
 *
 *
 */

void IntLinkedList::addToStart( int )
{
}

void IntLinkedList::showAll() const
{
}
