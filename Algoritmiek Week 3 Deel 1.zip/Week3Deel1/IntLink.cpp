#include "stdafx.h"

#include "IntLink.h"


IntLink::IntLink()
{
}

IntLink::IntLink( int, IntLink* )
{
}

IntLink::~IntLink()
{
}
