#include "stdafx.h"

#include "NAWLinkedList.h"

#include "NAW.h"
#include "NAWLink.h"

#include <iostream>

/*
 * opdracht 1
 */

NAWLinkedList::NAWLinkedList()
{
}


NAWLinkedList::~NAWLinkedList()
{
}

void NAWLinkedList::addToStart( const NAW& )
{
}

NAWLink* NAWLinkedList::search( const NAW& ) const
{
    return nullptr;
}

void NAWLinkedList::showAll() const
{
}

NAWLink* NAWLinkedList::removeFirst( const NAW& )
{
    return nullptr;
}
